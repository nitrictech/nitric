import { TerraformModule, TerraformModuleUserConfig } from 'cdktf';
import { Construct } from 'constructs';
export interface RolesConfig extends TerraformModuleUserConfig {
    /**
    * The name of the resource group
    */
    readonly resourceGroupName: string;
    /**
    * The id of the stack
    */
    readonly stackId: string;
}
/**
* Defines an Roles based on a Terraform module
*
* Source at ./.nitric/modules/roles
*/
export declare class Roles extends TerraformModule {
    private readonly inputs;
    constructor(scope: Construct, id: string, config: RolesConfig);
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get stackId(): string;
    set stackId(value: string);
    get allowUserDelegationKeyGenerationOutput(): string;
    get bucketDeleteOutput(): string;
    get bucketListOutput(): string;
    get bucketReadOutput(): string;
    get bucketWriteOutput(): string;
    get kvDeleteOutput(): string;
    get kvReadOutput(): string;
    get kvWriteOutput(): string;
    get queueDequeueOutput(): string;
    get queueEnqueueOutput(): string;
    get secretAccessOutput(): string;
    get secretPutOutput(): string;
    get topicPublishOutput(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
