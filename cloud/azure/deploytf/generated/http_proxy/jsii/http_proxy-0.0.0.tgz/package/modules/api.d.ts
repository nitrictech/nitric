import { TerraformModule, TerraformModuleUserConfig } from 'cdktf';
import { Construct } from 'constructs';
export interface ApiConfig extends TerraformModuleUserConfig {
    /**
    * The identity of the app
    */
    readonly appIdentity: string;
    /**
    * The description of the API
    */
    readonly description: string;
    /**
    * The location of the API
    */
    readonly location: string;
    /**
    * The name of the API
    */
    readonly name: string;
    /**
    * The openapi spec to deploy
    */
    readonly openapiSpec: string;
    /**
    * The policy templates to apply
    * The property type contains a map, they have special handling, please see {@link cdk.tf/module-map-inputs the docs}
    */
    readonly operationPolicyTemplates: {
        [key: string]: string;
    };
    /**
    * The email of the publisher
    */
    readonly publisherEmail: string;
    /**
    * The name of the publisher
    */
    readonly publisherName: string;
    /**
    * The name of the resource group
    */
    readonly resourceGroupName: string;
}
/**
* Defines an Api based on a Terraform module
*
* Source at ./.nitric/modules/api
*/
export declare class Api extends TerraformModule {
    private readonly inputs;
    constructor(scope: Construct, id: string, config: ApiConfig);
    get appIdentity(): string;
    set appIdentity(value: string);
    get description(): string;
    set description(value: string);
    get location(): string;
    set location(value: string);
    get name(): string;
    set name(value: string);
    get openapiSpec(): string;
    set openapiSpec(value: string);
    get operationPolicyTemplates(): {
        [key: string]: string;
    };
    set operationPolicyTemplates(value: {
        [key: string]: string;
    });
    get publisherEmail(): string;
    set publisherEmail(value: string);
    get publisherName(): string;
    set publisherName(value: string);
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get apiGatewayUrlOutput(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
