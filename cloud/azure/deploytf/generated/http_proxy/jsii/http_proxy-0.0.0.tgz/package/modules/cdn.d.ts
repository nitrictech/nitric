import { TerraformModule, TerraformModuleUserConfig } from 'cdktf';
import { Construct } from 'constructs';
export interface CdnConfig extends TerraformModuleUserConfig {
    /**
    * Map of APIs and their gateway information
    */
    readonly apis?: any;
    /**
    * The location/region where the resources will be created
    */
    readonly location: string;
    /**
    * The name of the resource group to use for the cdn
    */
    readonly resourceGroupName: string;
    /**
    * The name of the stack
    */
    readonly stackName: string;
    /**
    * The id of the storage account to use for the cdn
    */
    readonly storageAccountId: string;
    /**
    * The name of the storage account to use for the cdn
    */
    readonly storageAccountName: string;
    /**
    * The primary web host of the storage account to use for the cdn
    */
    readonly storageAccountPrimaryWebHost: string;
}
/**
* Defines an Cdn based on a Terraform module
*
* Source at ./.nitric/modules/cdn
*/
export declare class Cdn extends TerraformModule {
    private readonly inputs;
    constructor(scope: Construct, id: string, config: CdnConfig);
    get apis(): any | undefined;
    set apis(value: any | undefined);
    get location(): string;
    set location(value: string);
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get stackName(): string;
    set stackName(value: string);
    get storageAccountId(): string;
    set storageAccountId(value: string);
    get storageAccountName(): string;
    set storageAccountName(value: string);
    get storageAccountPrimaryWebHost(): string;
    set storageAccountPrimaryWebHost(value: string);
    get cdnUrlOutput(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
