import { TerraformModule, TerraformModuleUserConfig } from 'cdktf';
import { Construct } from 'constructs';
export interface ServiceConfig extends TerraformModuleUserConfig {
    /**
    * The id of the container app environment
    */
    readonly containerAppEnvironmentId: string;
    /**
    * The cpu limit for the container
    */
    readonly cpu: number;
    /**
    * The environment variables to set
    * The property type contains a map, they have special handling, please see {@link cdk.tf/module-map-inputs the docs}
    */
    readonly env: {
        [key: string]: string;
    };
    /**
    * The image uri for the container
    */
    readonly imageUri: string;
    /**
    * Maximum number of replicas for the service
    */
    readonly maxReplicas: number;
    /**
    * The memory limit for the container
    */
    readonly memory: string;
    /**
    * Minimum number of replicas for the service
    */
    readonly minReplicas: number;
    /**
    * The name of the service
    */
    readonly name: string;
    /**
    * The login server for the container registry
    */
    readonly registryLoginServer: string;
    /**
    * The password for the container registry
    */
    readonly registryPassword: string;
    /**
    * The username for the container registry
    */
    readonly registryUsername: string;
    /**
    * The name of the resource group
    */
    readonly resourceGroupName: string;
    /**
    * The name of the stack
    */
    readonly stackName: string;
}
/**
* Defines an Service based on a Terraform module
*
* Source at ./.nitric/modules/service
*/
export declare class Service extends TerraformModule {
    private readonly inputs;
    constructor(scope: Construct, id: string, config: ServiceConfig);
    get containerAppEnvironmentId(): string;
    set containerAppEnvironmentId(value: string);
    get cpu(): number;
    set cpu(value: number);
    get env(): {
        [key: string]: string;
    };
    set env(value: {
        [key: string]: string;
    });
    get imageUri(): string;
    set imageUri(value: string);
    get maxReplicas(): number;
    set maxReplicas(value: number);
    get memory(): string;
    set memory(value: string);
    get minReplicas(): number;
    set minReplicas(value: number);
    get name(): string;
    set name(value: string);
    get registryLoginServer(): string;
    set registryLoginServer(value: string);
    get registryPassword(): string;
    set registryPassword(value: string);
    get registryUsername(): string;
    set registryUsername(value: string);
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get stackName(): string;
    set stackName(value: string);
    get clientIdOutput(): string;
    get clientSecretOutput(): string;
    get containerAppIdOutput(): string;
    get daprAppIdOutput(): string;
    get endpointOutput(): string;
    get eventTokenOutput(): string;
    get fqdnOutput(): string;
    get pollUrlOutput(): string;
    get servicePrincipalIdOutput(): string;
    get tenantIdOutput(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
