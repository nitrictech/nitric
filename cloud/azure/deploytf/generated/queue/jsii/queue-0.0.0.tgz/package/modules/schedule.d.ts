import { TerraformModule, TerraformModuleUserConfig } from 'cdktf';
import { Construct } from 'constructs';
export interface ScheduleConfig extends TerraformModuleUserConfig {
    /**
    * The container app environment id
    */
    readonly containerAppEnvironmentId: string;
    /**
    * The cron expression for the schedule
    */
    readonly cronExpression: string;
    /**
    * The name of the schedule
    */
    readonly name: string;
    /**
    * The target app id for the schedule
    */
    readonly targetAppId: string;
    /**
    * The target event token for the schedule
    */
    readonly targetEventToken: string;
}
/**
* Defines an Schedule based on a Terraform module
*
* Source at ./.nitric/modules/schedule
*/
export declare class Schedule extends TerraformModule {
    private readonly inputs;
    constructor(scope: Construct, id: string, config: ScheduleConfig);
    get containerAppEnvironmentId(): string;
    set containerAppEnvironmentId(value: string);
    get cronExpression(): string;
    set cronExpression(value: string);
    get name(): string;
    set name(value: string);
    get targetAppId(): string;
    set targetAppId(value: string);
    get targetEventToken(): string;
    set targetEventToken(value: string);
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
