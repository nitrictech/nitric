import { TerraformModule, TerraformModuleUserConfig } from 'cdktf';
import { Construct } from 'constructs';
export interface TopicConfig extends TerraformModuleUserConfig {
    /**
    * The list of listeners to notify
    */
    readonly listeners: any;
    /**
    * The location of the topic
    */
    readonly location: string;
    /**
    * The name of the topic
    */
    readonly name: string;
    /**
    * The name of the resource group
    */
    readonly resourceGroupName: string;
    /**
    * The name of the stack
    */
    readonly stackName: string;
    /**
    * The tags to apply to the topic
    * The property type contains a map, they have special handling, please see {@link cdk.tf/module-map-inputs the docs}
    */
    readonly tags: {
        [key: string]: string;
    };
}
/**
* Defines an Topic based on a Terraform module
*
* Source at ./.nitric/modules/topic
*/
export declare class Topic extends TerraformModule {
    private readonly inputs;
    constructor(scope: Construct, id: string, config: TopicConfig);
    get listeners(): any;
    set listeners(value: any);
    get location(): string;
    set location(value: string);
    get name(): string;
    set name(value: string);
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get stackName(): string;
    set stackName(value: string);
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
