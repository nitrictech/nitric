import { TerraformModule, TerraformModuleUserConfig } from 'cdktf';
import { Construct } from 'constructs';
export interface CdnApiRewritesConfig extends TerraformModuleUserConfig {
    /**
    * The host name of the api
    */
    readonly apiHostName: string;
    /**
    * The id of the cdn frontdoor profile to use for the cdn
    */
    readonly cdnFrontdoorProfileId: string;
    /**
    * The id of the default cdn frontdoor rule set to use for the cdn
    */
    readonly cdnFrontdoorRuleSetId: string;
    /**
    * The name of the api
    */
    readonly name: string;
    /**
    * The order of the rule to use for the cdn
    * 1
    */
    readonly ruleOrder?: number;
}
/**
* Defines an CdnApiRewrites based on a Terraform module
*
* Source at ./.nitric/modules/cdn_api_rewrites
*/
export declare class CdnApiRewrites extends TerraformModule {
    private readonly inputs;
    constructor(scope: Construct, id: string, config: CdnApiRewritesConfig);
    get apiHostName(): string;
    set apiHostName(value: string);
    get cdnFrontdoorProfileId(): string;
    set cdnFrontdoorProfileId(value: string);
    get cdnFrontdoorRuleSetId(): string;
    set cdnFrontdoorRuleSetId(value: string);
    get name(): string;
    set name(value: string);
    get ruleOrder(): number | undefined;
    set ruleOrder(value: number | undefined);
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
