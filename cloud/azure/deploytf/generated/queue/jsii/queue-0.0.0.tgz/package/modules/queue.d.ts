import { TerraformModule, TerraformModuleUserConfig } from 'cdktf';
import { Construct } from 'constructs';
export interface QueueConfig extends TerraformModuleUserConfig {
    /**
    * the name of the queue
    */
    readonly name: string;
    /**
    * the name of the storage account
    */
    readonly storageAccountName: string;
    /**
    * the tags to apply to the queue
    * The property type contains a map, they have special handling, please see {@link cdk.tf/module-map-inputs the docs}
    */
    readonly tags: {
        [key: string]: string;
    };
}
/**
* Defines an Queue based on a Terraform module
*
* Source at ./.nitric/modules/queue
*/
export declare class Queue extends TerraformModule {
    private readonly inputs;
    constructor(scope: Construct, id: string, config: QueueConfig);
    get name(): string;
    set name(value: string);
    get storageAccountName(): string;
    set storageAccountName(value: string);
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    get queueIdOutput(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
