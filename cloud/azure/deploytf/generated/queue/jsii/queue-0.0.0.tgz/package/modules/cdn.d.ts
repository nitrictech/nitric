import { TerraformModule, TerraformModuleUserConfig } from 'cdktf';
import { Construct } from 'constructs';
export interface CdnConfig extends TerraformModuleUserConfig {
    /**
    * Custom domain host name
    */
    readonly customDomainHostName: string;
    /**
    * The domain name for the CDN
    */
    readonly domainName: string;
    /**
    * Enable API rewrites
    */
    readonly enableApiRewrites?: boolean;
    /**
    * Enable custom domains
    */
    readonly enableCustomDomain?: boolean;
    /**
    * Is the custom domain an apex domain
    */
    readonly isApexDomain?: boolean;
    /**
    * The primary host for the CDN
    */
    readonly primaryWebHost: string;
    /**
    * The name of the resource group to use for the cdn
    */
    readonly resourceGroupName: string;
    /**
    * Skip cache invalidation
    */
    readonly skipCacheInvalidation?: boolean;
    /**
    * The name of the stack
    */
    readonly stackName: string;
    /**
    * Map of uploaded files with their MD5 hashes
    * The property type contains a map, they have special handling, please see {@link cdk.tf/module-map-inputs the docs}
    */
    readonly uploadedFiles?: {
        [key: string]: string;
    };
    /**
    * The name of the CDN zone
    */
    readonly zoneName: string;
    /**
    * The name of the resource group for the CDN zone
    */
    readonly zoneResourceGroupName: string;
}
/**
* Defines an Cdn based on a Terraform module
*
* Source at ./.nitric/modules/cdn
*/
export declare class Cdn extends TerraformModule {
    private readonly inputs;
    constructor(scope: Construct, id: string, config: CdnConfig);
    get customDomainHostName(): string;
    set customDomainHostName(value: string);
    get domainName(): string;
    set domainName(value: string);
    get enableApiRewrites(): boolean | undefined;
    set enableApiRewrites(value: boolean | undefined);
    get enableCustomDomain(): boolean | undefined;
    set enableCustomDomain(value: boolean | undefined);
    get isApexDomain(): boolean | undefined;
    set isApexDomain(value: boolean | undefined);
    get primaryWebHost(): string;
    set primaryWebHost(value: string);
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get skipCacheInvalidation(): boolean | undefined;
    set skipCacheInvalidation(value: boolean | undefined);
    get stackName(): string;
    set stackName(value: string);
    get uploadedFiles(): {
        [key: string]: string;
    } | undefined;
    set uploadedFiles(value: {
        [key: string]: string;
    } | undefined);
    get zoneName(): string;
    set zoneName(value: string);
    get zoneResourceGroupName(): string;
    set zoneResourceGroupName(value: string);
    get cdnFrontdoorApiRuleSetIdOutput(): string;
    get cdnFrontdoorDefaultRuleSetIdOutput(): string;
    get cdnFrontdoorProfileIdOutput(): string;
    get cdnUrlOutput(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
