import { TerraformModule, TerraformModuleUserConfig } from 'cdktf';
import { Construct } from 'constructs';
export interface SqlConfig extends TerraformModuleUserConfig {
    /**
    * The database master password
    */
    readonly databaseMasterPassword: string;
    /**
    * The database server fully qualified domain name
    */
    readonly databaseServerFqdn: string;
    /**
    * The image registry password
    */
    readonly imageRegistryPassword: string;
    /**
    * The image registry server
    */
    readonly imageRegistryServer: string;
    /**
    * The image registry username
    */
    readonly imageRegistryUsername: string;
    /**
    * The location/region the migration container should be deployed
    */
    readonly location: string;
    /**
    * The subnet id to deploy the migration container
    */
    readonly migrationContainerSubnetId: string;
    /**
    * The migration image to use
    */
    readonly migrationImageUri: string;
    /**
    * The name of the database
    */
    readonly name: string;
    /**
    * The name of the resource group
    */
    readonly resourceGroupName: string;
    /**
    * The id of the postgresql flexible server
    */
    readonly serverId: string;
    /**
    * The name of the stack
    */
    readonly stackName: string;
}
/**
* Defines an Sql based on a Terraform module
*
* Source at ./.nitric/modules/sql
*/
export declare class Sql extends TerraformModule {
    private readonly inputs;
    constructor(scope: Construct, id: string, config: SqlConfig);
    get databaseMasterPassword(): string;
    set databaseMasterPassword(value: string);
    get databaseServerFqdn(): string;
    set databaseServerFqdn(value: string);
    get imageRegistryPassword(): string;
    set imageRegistryPassword(value: string);
    get imageRegistryServer(): string;
    set imageRegistryServer(value: string);
    get imageRegistryUsername(): string;
    set imageRegistryUsername(value: string);
    get location(): string;
    set location(value: string);
    get migrationContainerSubnetId(): string;
    set migrationContainerSubnetId(value: string);
    get migrationImageUri(): string;
    set migrationImageUri(value: string);
    get name(): string;
    set name(value: string);
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get serverId(): string;
    set serverId(value: string);
    get stackName(): string;
    set stackName(value: string);
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
