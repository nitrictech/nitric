import { TerraformModule, TerraformModuleUserConfig } from 'cdktf';
import { Construct } from 'constructs';
export interface PolicyConfig extends TerraformModuleUserConfig {
    /**
    * The role definition id
    */
    readonly roleDefinitionId: string;
    /**
    * The scope of the role assignment
    */
    readonly scope: string;
    /**
    * The service principal id
    */
    readonly servicePrincipalId: string;
}
/**
* Defines an Policy based on a Terraform module
*
* Source at ./.nitric/modules/policy
*/
export declare class Policy extends TerraformModule {
    private readonly inputs;
    constructor(scope: Construct, id: string, config: PolicyConfig);
    get roleDefinitionId(): string;
    set roleDefinitionId(value: string);
    get scope(): string;
    set scope(value: string);
    get servicePrincipalId(): string;
    set servicePrincipalId(value: string);
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
