import { TerraformModule, TerraformModuleUserConfig } from 'cdktf';
import { Construct } from 'constructs';
export interface WebsiteConfig extends TerraformModuleUserConfig {
    /**
    * The base path for the website
    */
    readonly basePath: string;
    /**
    * The error document for the website
    * 404.html
    */
    readonly errorDocument?: string;
    /**
    * The index document for the website
    * index.html
    */
    readonly indexDocument?: string;
    /**
    * The local directory to deploy the website from
    */
    readonly localDirectory: string;
    /**
    * The location/region where the resources will be created
    */
    readonly location: string;
    /**
    * The name of the resource group to use for the cdn
    */
    readonly resourceGroupName: string;
    /**
    * The name of the stack
    */
    readonly stackName: string;
}
/**
* Defines an Website based on a Terraform module
*
* Source at ./.nitric/modules/website
*/
export declare class Website extends TerraformModule {
    private readonly inputs;
    constructor(scope: Construct, id: string, config: WebsiteConfig);
    get basePath(): string;
    set basePath(value: string);
    get errorDocument(): string | undefined;
    set errorDocument(value: string | undefined);
    get indexDocument(): string | undefined;
    set indexDocument(value: string | undefined);
    get localDirectory(): string;
    set localDirectory(value: string);
    get location(): string;
    set location(value: string);
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get stackName(): string;
    set stackName(value: string);
    get storageAccountWebHostOutput(): string;
    get uploadedFilesOutput(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
