import { TerraformModule, TerraformModuleUserConfig } from 'cdktf';
import { Construct } from 'constructs';
export interface BucketConfig extends TerraformModuleUserConfig {
    /**
    * The list of listeners to notify
    */
    readonly listeners: any;
    /**
    * The name of the bucket
    */
    readonly name: string;
    /**
    * The name of the stack
    */
    readonly stackName: string;
    /**
    * The id of the storage account
    */
    readonly storageAccountId: string;
    /**
    * The tags to apply to the bucket
    * The property type contains a map, they have special handling, please see {@link cdk.tf/module-map-inputs the docs}
    */
    readonly tags: {
        [key: string]: string;
    };
}
/**
* Defines an Bucket based on a Terraform module
*
* Source at ./.nitric/modules/bucket
*/
export declare class Bucket extends TerraformModule {
    private readonly inputs;
    constructor(scope: Construct, id: string, config: BucketConfig);
    get listeners(): any;
    set listeners(value: any);
    get name(): string;
    set name(value: string);
    get stackName(): string;
    set stackName(value: string);
    get storageAccountId(): string;
    set storageAccountId(value: string);
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
