import { TerraformModule, TerraformModuleUserConfig } from 'cdktf';
import { Construct } from 'constructs';
export interface StackConfig extends TerraformModuleUserConfig {
    /**
    * Enable the creation of a database
    */
    readonly enableDatabase?: boolean;
    /**
    * Enable the creation of a keyvault
    */
    readonly enableKeyvault?: boolean;
    /**
    * Enable the creation of a storage account
    */
    readonly enableStorage?: boolean;
    /**
    * Enable private endpoints for the storage account
    */
    readonly enableStoragePrivateEndpoints?: boolean;
    /**
    * The id of the subnet to deploy the infrastructure resources
    */
    readonly infrastructureSubnetId?: string;
    /**
    * The location/region where the resources will be created
    */
    readonly location: string;
    /**
    * The name of the stack
    */
    readonly stackName: string;
    /**
    * The tags to apply to the stack
    * The property type contains a map, they have special handling, please see {@link cdk.tf/module-map-inputs the docs}
    */
    readonly tags: {
        [key: string]: string;
    };
}
/**
* Defines an Stack based on a Terraform module
*
* Source at ./.nitric/modules/stack
*/
export declare class Stack extends TerraformModule {
    private readonly inputs;
    constructor(scope: Construct, id: string, config: StackConfig);
    get enableDatabase(): boolean | undefined;
    set enableDatabase(value: boolean | undefined);
    get enableKeyvault(): boolean | undefined;
    set enableKeyvault(value: boolean | undefined);
    get enableStorage(): boolean | undefined;
    set enableStorage(value: boolean | undefined);
    get enableStoragePrivateEndpoints(): boolean | undefined;
    set enableStoragePrivateEndpoints(value: boolean | undefined);
    get infrastructureSubnetId(): string | undefined;
    set infrastructureSubnetId(value: string | undefined);
    get location(): string;
    set location(value: string);
    get stackName(): string;
    set stackName(value: string);
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    get appIdentityOutput(): string;
    get appIdentityClientIdOutput(): string;
    get containerAppEnvironmentIdOutput(): string;
    get containerAppSubnetIdOutput(): string;
    get databaseMasterPasswordOutput(): string;
    get databaseServerFqdnOutput(): string;
    get databaseServerIdOutput(): string;
    get databaseServerNameOutput(): string;
    get infrastructureSubnetIdOutput(): string;
    get keyvaultNameOutput(): string;
    get registryLoginServerOutput(): string;
    get registryPasswordOutput(): string;
    get registryUsernameOutput(): string;
    get resourceGroupNameOutput(): string;
    get stackIdOutput(): string;
    get stackNameOutput(): string;
    get storageAccountBlobEndpointOutput(): string;
    get storageAccountConnectionStringOutput(): string;
    get storageAccountIdOutput(): string;
    get storageAccountNameOutput(): string;
    get storageAccountQueueEndpointOutput(): string;
    get storagePrivateEndpointIpOutput(): string;
    get subscriptionIdOutput(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
