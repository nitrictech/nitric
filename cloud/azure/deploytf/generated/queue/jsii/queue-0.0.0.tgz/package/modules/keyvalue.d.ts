import { TerraformModule, TerraformModuleUserConfig } from 'cdktf';
import { Construct } from 'constructs';
export interface KeyvalueConfig extends TerraformModuleUserConfig {
    /**
    * The name of the kv store
    */
    readonly name: string;
    /**
    * The name of the storage account
    */
    readonly storageAccountName: string;
}
/**
* Defines an Keyvalue based on a Terraform module
*
* Source at ./.nitric/modules/keyvalue
*/
export declare class Keyvalue extends TerraformModule {
    private readonly inputs;
    constructor(scope: Construct, id: string, config: KeyvalueConfig);
    get name(): string;
    set name(value: string);
    get storageAccountName(): string;
    set storageAccountName(value: string);
    get tableIdOutput(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
