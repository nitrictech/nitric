import { TerraformModule, TerraformModuleUserConfig } from 'cdktf';
import { Construct } from 'constructs';
export interface CdnSubsitesConfig extends TerraformModuleUserConfig {
    /**
    * The host name of the api
    */
    readonly basePath: string;
    /**
    * The id of the default cdn frontdoor rule set to use for the cdn
    */
    readonly cdnDefaultFrontdoorRuleSetId: string;
    /**
    * The id of the cdn frontdoor profile to use for the cdn
    */
    readonly cdnFrontdoorProfileId: string;
    /**
    * The name of the api
    */
    readonly name: string;
    /**
    * The primary host for the website
    */
    readonly primaryWebHost: string;
    /**
    * The order of the rule to use for the cdn
    * 1
    */
    readonly ruleOrder?: number;
    /**
    * The name of the stack
    */
    readonly stackName: string;
}
/**
* Defines an CdnSubsites based on a Terraform module
*
* Source at ./.nitric/modules/cdn_subsites
*/
export declare class CdnSubsites extends TerraformModule {
    private readonly inputs;
    constructor(scope: Construct, id: string, config: CdnSubsitesConfig);
    get basePath(): string;
    set basePath(value: string);
    get cdnDefaultFrontdoorRuleSetId(): string;
    set cdnDefaultFrontdoorRuleSetId(value: string);
    get cdnFrontdoorProfileId(): string;
    set cdnFrontdoorProfileId(value: string);
    get name(): string;
    set name(value: string);
    get primaryWebHost(): string;
    set primaryWebHost(value: string);
    get ruleOrder(): number | undefined;
    set ruleOrder(value: number | undefined);
    get stackName(): string;
    set stackName(value: string);
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
