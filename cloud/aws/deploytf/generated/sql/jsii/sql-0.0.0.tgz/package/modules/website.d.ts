import { TerraformModule, TerraformModuleUserConfig } from 'cdktf';
import { Construct } from 'constructs';
export interface WebsiteConfig extends TerraformModuleUserConfig {
    /**
    * The base path for the website
    */
    readonly basePath: string;
    /**
    * The production website output directory
    */
    readonly localDirectory: string;
    /**
    * The name of the website
    */
    readonly name: string;
    /**
    * The name of the bucket to deploy the website files to
    */
    readonly websiteBucketName: string;
}
/**
* Defines an Website based on a Terraform module
*
* Source at ./.nitric/modules/website
*/
export declare class Website extends TerraformModule {
    private readonly inputs;
    constructor(scope: Construct, id: string, config: WebsiteConfig);
    get basePath(): string;
    set basePath(value: string);
    get localDirectory(): string;
    set localDirectory(value: string);
    get name(): string;
    set name(value: string);
    get websiteBucketName(): string;
    set websiteBucketName(value: string);
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
