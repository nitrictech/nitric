import { TerraformModule, TerraformModuleUserConfig } from 'cdktf';
import { Construct } from 'constructs';
export interface CdnConfig extends TerraformModuleUserConfig {
    /**
    * Map of APIs and their gateway information
    */
    readonly apis?: any;
    /**
    * The name of the stack
    */
    readonly stackName: string;
    /**
    * The ARN for the website bucket
    */
    readonly websiteBucketArn: string;
    /**
    * The domain name for the website bucket
    */
    readonly websiteBucketDomainName: string;
    /**
    * The ID for the website bucket
    */
    readonly websiteBucketId: string;
    /**
    * The website error document
    * 404.html
    */
    readonly websiteErrorDocument?: string;
    /**
    * The website index document
    * index.html
    */
    readonly websiteIndexDocument?: string;
}
/**
* Defines an Cdn based on a Terraform module
*
* Source at ./.nitric/modules/cdn
*/
export declare class Cdn extends TerraformModule {
    private readonly inputs;
    constructor(scope: Construct, id: string, config: CdnConfig);
    get apis(): any | undefined;
    set apis(value: any | undefined);
    get stackName(): string;
    set stackName(value: string);
    get websiteBucketArn(): string;
    set websiteBucketArn(value: string);
    get websiteBucketDomainName(): string;
    set websiteBucketDomainName(value: string);
    get websiteBucketId(): string;
    set websiteBucketId(value: string);
    get websiteErrorDocument(): string | undefined;
    set websiteErrorDocument(value: string | undefined);
    get websiteIndexDocument(): string | undefined;
    set websiteIndexDocument(value: string | undefined);
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
