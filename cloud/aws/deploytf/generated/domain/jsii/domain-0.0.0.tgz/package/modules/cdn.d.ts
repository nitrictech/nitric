import { TerraformModule, TerraformModuleUserConfig } from 'cdktf';
import { Construct } from 'constructs';
export interface CdnConfig extends TerraformModuleUserConfig {
    /**
    * Map of APIs and their gateway information
    */
    readonly apis?: any;
    /**
    * information about the root website for default behaviour
    */
    readonly rootWebsite: any;
    /**
    * The name of the stack
    */
    readonly stackName: string;
    /**
    * Map of websites and their storage information
    */
    readonly websites: any;
}
/**
* Defines an Cdn based on a Terraform module
*
* Source at ./.nitric/modules/cdn
*/
export declare class Cdn extends TerraformModule {
    private readonly inputs;
    constructor(scope: Construct, id: string, config: CdnConfig);
    get apis(): any | undefined;
    set apis(value: any | undefined);
    get rootWebsite(): any;
    set rootWebsite(value: any);
    get stackName(): string;
    set stackName(value: string);
    get websites(): any;
    set websites(value: any);
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
