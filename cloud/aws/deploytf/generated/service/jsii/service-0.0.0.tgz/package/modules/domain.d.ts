import { TerraformModule, TerraformModuleUserConfig } from 'cdktf';
import { Construct } from 'constructs';
export interface DomainConfig extends TerraformModuleUserConfig {
    /**
    * The ID of the API
    */
    readonly apiId: string;
    /**
    * The stage for the API
    */
    readonly apiStageName: string;
    /**
    * The name of the domain. This must be globally unique.
    */
    readonly domainName: string;
    /**
    * The ID of the Nitric stack
    */
    readonly stackId: string;
}
/**
* Defines an Domain based on a Terraform module
*
* Source at ./.nitric/modules/domain
*/
export declare class Domain extends TerraformModule {
    private readonly inputs;
    constructor(scope: Construct, id: string, config: DomainConfig);
    get apiId(): string;
    set apiId(value: string);
    get apiStageName(): string;
    set apiStageName(value: string);
    get domainName(): string;
    set domainName(value: string);
    get stackId(): string;
    set stackId(value: string);
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
