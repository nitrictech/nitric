import { TerraformModule, TerraformModuleUserConfig } from 'cdktf';
import { Construct } from 'constructs';
export interface CdnConfig extends TerraformModuleUserConfig {
    /**
    * Map of APIs and their gateway information
    */
    readonly apis?: any;
    /**
    * Certificate ARN for us-east-1 specific certificate
    */
    readonly certificateArn?: string;
    /**
    * Custom domain for distribution
    */
    readonly domainName?: string;
    /**
    * information about the root website for default behaviour
    */
    readonly rootWebsite: any;
    /**
    * Skip invalidating the cache. Defaults to false.
    */
    readonly skipCacheInvalidation?: boolean;
    /**
    * The name of the stack
    */
    readonly stackName: string;
    /**
    * Map of websites and their storage information
    */
    readonly websites: any;
}
/**
* Defines an Cdn based on a Terraform module
*
* Source at ./.nitric/modules/cdn
*/
export declare class Cdn extends TerraformModule {
    private readonly inputs;
    constructor(scope: Construct, id: string, config: CdnConfig);
    get apis(): any | undefined;
    set apis(value: any | undefined);
    get certificateArn(): string | undefined;
    set certificateArn(value: string | undefined);
    get domainName(): string | undefined;
    set domainName(value: string | undefined);
    get rootWebsite(): any;
    set rootWebsite(value: any);
    get skipCacheInvalidation(): boolean | undefined;
    set skipCacheInvalidation(value: boolean | undefined);
    get stackName(): string;
    set stackName(value: string);
    get websites(): any;
    set websites(value: any);
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
