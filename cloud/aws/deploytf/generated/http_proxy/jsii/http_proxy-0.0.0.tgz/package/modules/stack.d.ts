import { TerraformModule, TerraformModuleUserConfig } from 'cdktf';
import { Construct } from 'constructs';
export interface StackConfig extends TerraformModuleUserConfig {
    /**
    * Enable the creation of a website
    */
    readonly enableWebsite?: boolean;
    /**
    * The root error document for the website
    * 404.html
    */
    readonly websiteRootErrorDocument?: string;
    /**
    * The root index document for the website
    * index.html
    */
    readonly websiteRootIndexDocument?: string;
}
/**
* Defines an Stack based on a Terraform module
*
* Source at ./.nitric/modules/stack
*/
export declare class Stack extends TerraformModule {
    private readonly inputs;
    constructor(scope: Construct, id: string, config?: StackConfig);
    get enableWebsite(): boolean | undefined;
    set enableWebsite(value: boolean | undefined);
    get websiteRootErrorDocument(): string | undefined;
    set websiteRootErrorDocument(value: string | undefined);
    get websiteRootIndexDocument(): string | undefined;
    set websiteRootIndexDocument(value: string | undefined);
    get stackIdOutput(): string;
    get websiteBucketNameOutput(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
