import { TerraformModule, TerraformModuleUserConfig } from 'cdktf';
import { Construct } from 'constructs';
export interface BucketConfig extends TerraformModuleUserConfig {
    /**
    * The name of the bucket
    */
    readonly bucketName: string;
    /**
    * The KMS key to use for encryption
    */
    readonly kmsKey?: string;
    /**
    * The notification target configurations
    */
    readonly notificationTargets: any;
    /**
    * The ID of the Nitric stack
    */
    readonly stackId: string;
    /**
    * The class of storage used to store the bucket's contents. This can be STANDARD, NEARLINE, COLDLINE, ARCHIVE, or MULTI_REGIONAL.
    * STANDARD
    */
    readonly storageClass?: string;
}
/**
* Defines an Bucket based on a Terraform module
*
* Source at ./.nitric/modules/bucket
*/
export declare class Bucket extends TerraformModule {
    private readonly inputs;
    constructor(scope: Construct, id: string, config: BucketConfig);
    get bucketName(): string;
    set bucketName(value: string);
    get kmsKey(): string | undefined;
    set kmsKey(value: string | undefined);
    get notificationTargets(): any;
    set notificationTargets(value: any);
    get stackId(): string;
    set stackId(value: string);
    get storageClass(): string | undefined;
    set storageClass(value: string | undefined);
    get bucketLocationOutput(): string;
    get bucketStorageClassOutput(): string;
    get nameOutput(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
